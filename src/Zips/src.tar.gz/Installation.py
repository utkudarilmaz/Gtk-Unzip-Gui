import gi
import os
import tarfile
from TarFile import TarFile


gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from gi.repository import GObject


class Installation(Gtk.Assistant):


    def __init__(self):
        Gtk.Assistant.__init__(self)
        self.connect("delete-event",Gtk.main_quit)
        self.connect("cancel", self.on_cancel_clicked)
        self.connect("close", self.on_close_clicked)
        self.connect("apply", self.on_apply_clicked)
        self.set_default_size(720,460)
        self.set_resizable(False)

        ## Giris Ekranı

        box=Gtk.Box()
        label=Gtk.Label(label="Welcome to installation. This program an example for assistan widget and setup tools")
        label.set_line_wrap(True)
        self.append_page(box)
        self.set_page_title(box,"Introduction")
        self.set_page_type(box,Gtk.AssistantPageType.INTRO)
        box.pack_start(label,True,False,0)
        self.set_page_complete(box,True)

        ## Sözleşme Ekranı

        self.box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=5)
        self.append_page(self.box)
        self.set_page_type(self.box, Gtk.AssistantPageType.CONTENT)
        self.set_page_title(self.box, "Sözleşme")

        scrolled=Gtk.ScrolledWindow()
        scrolled.set_border_width(5)
        scrolled.set_min_content_height(300)
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC,Gtk.PolicyType.AUTOMATIC)

        text=open('Aggrement/agg','r')
        label=Gtk.Label(label=text.read())
        text.close()

        label.set_line_wrap(True)
        scrolled.add_with_viewport(label)

        checkbutton = Gtk.CheckButton(label="Sözleşmeyi okuduğumu ve imzaladığımı kabul ediyorum")
        checkbutton.connect("toggled", self.on_accept_aggrement)
        self.box.pack_start(scrolled,True,True,0)
        self.box.pack_start(checkbutton,True,True,0)

        ## Kurulacak modullerin seçimi

        self.box_module=Gtk.Box()
        self.append_page(self.box_module)
        self.set_page_title(self.box_module,"Module Selection")
        self.set_page_type(self.box_module,Gtk.AssistantPageType.CONTENT)
        list_zip=os.listdir("/home/utku/PycharmProjects/Installation_GUI/src/Zips")

        self.liststoremodules=Gtk.ListStore(str,bool)

        for i in range(len(list_zip)) :
            self.liststoremodules.append([list_zip[i],False])

        treeviewmodule=Gtk.TreeView()
        treeviewmodule.set_model(self.liststoremodules)

        cellrenderertext=Gtk.CellRendererText()
        cellrenderertoggle=Gtk.CellRendererToggle()
        cellrenderertoggle.connect("toggled",self.toggled_module)

        treeviewcolumn=Gtk.TreeViewColumn("Module Name")
        treeviewcolumn.pack_start(cellrenderertext,False)
        treeviewcolumn.add_attribute(cellrenderertext, "text", 0)
        treeviewmodule.append_column(treeviewcolumn)

        treeviewcolumn=Gtk.TreeViewColumn("Status")
        treeviewcolumn.pack_start(cellrenderertoggle,False)
        treeviewcolumn.add_attribute(cellrenderertoggle,"active",1)
        treeviewmodule.append_column(treeviewcolumn)

        self.box_module.pack_start(treeviewmodule,True,True,0)
        self.set_page_complete(self.box_module,True)

        ## Destination Directory

        self.box2=Gtk.Box()
        self.append_page(self.box2)

        grid=Gtk.Grid()
        self.box2.pack_start(grid,True,True,0)

        self.set_page_title(self.box2, "Select Destination Directory")
        self.set_page_type(self.box2, Gtk.AssistantPageType.CONTENT)

        filechooserbutton=Gtk.FileChooserButton(title="Select Destination File")
        filechooserbutton.set_action(2)                                           ## Sadece dizin seçebilmeye ayarladık
        filechooserbutton.connect("file-set",self.on_select_file)

        label=Gtk.Label(label="Please select your destination directory!")
        label.set_halign(Gtk.Align.CENTER)
        label.set_line_wrap(True)
        grid.set_row_homogeneous(False)
        grid.add(label)
        grid.attach_next_to(filechooserbutton,label,Gtk.PositionType.BOTTOM,1,1)

        ## Onay Sayfası

        box=Gtk.VBox(spacing=0)
        self.append_page(box)
        self.set_page_title(box,"Verification")
        self.set_page_type(box,Gtk.AssistantPageType.CONFIRM)

        self.liststorechoosen=Gtk.ListStore(str)

        self.treeviewchoosen=Gtk.TreeView()
        self.treeviewchoosen.set_model(self.liststorechoosen)

        cellrenderertext=Gtk.CellRendererText()

        treeviewcolumn=Gtk.TreeViewColumn("Modules to Install")
        treeviewcolumn.pack_start(cellrenderertext,True)
        treeviewcolumn.add_attribute(cellrenderertext,"text",0)
        self.treeviewchoosen.append_column(treeviewcolumn)

        label=Gtk.Label()
        label.set_line_wrap(False)
        label.set_markup("Choosen modules will install.\n"
                         "If you sure <b>continuing the installation</b> please click the <u>Apply</u> button!")

        box.pack_start(self.treeviewchoosen,False,True,0)
        box.pack_end(label,False,False,0)
        self.set_page_complete(box,True)

        ## Extract Progress

        self.box_progress=Gtk.VBox()
        self.append_page(self.box_progress)
        self.set_page_title(self.box_progress,"Progress")
        self.set_page_type(self.box_progress,Gtk.AssistantPageType.CONTENT)

        self.liststoreprogress=Gtk.ListStore(str,int)
        self.treeviewprogress=Gtk.TreeView()
        self.treeviewprogress.set_model(self.liststoreprogress)

        cellrenderertext=Gtk.CellRendererText()
        cellrendererprogress=Gtk.CellRendererProgress()

        treeviewcolumn=Gtk.TreeViewColumn("Installing Modules")
        self.treeviewprogress.append_column(treeviewcolumn)
        treeviewcolumn.pack_start(cellrenderertext,False)
        treeviewcolumn.add_attribute(cellrenderertext,"text",0)

        treeviewcolumn=Gtk.TreeViewColumn("Progress")
        self.treeviewprogress.append_column(treeviewcolumn)
        treeviewcolumn.pack_start(cellrendererprogress,False)
        treeviewcolumn.add_attribute(cellrendererprogress,"value",1)

        self.box_progress.pack_start(self.treeviewprogress,True,True,0)

        GObject.timeout_add(250, self.on_pulse_progressbar)


    def on_apply_clicked(self, *args):

        if self.get_current_page() == 4 :
            self.push_progress_page()

    def on_close_clicked(self, *args):
        Gtk.main_quit()

    def on_cancel_clicked(self, *args):
        Gtk.main_quit()

    ## Sözleşme kutusu
    def on_accept_aggrement(self,checkbutton):
        self.set_page_complete(self.box, checkbutton.get_active())

    ## Modul secimi
    def toggled_module(self,widget,treepath):
        self.liststoremodules[treepath][1]=not self.liststoremodules[treepath][1]

        ## Eğer modül seçildiyse kaydet
        if self.liststoremodules[treepath][1] is True :
            self.liststorechoosen.append([self.liststoremodules[treepath][0]])
            self.treeviewchoosen.set_model(self.liststorechoosen)

        ## Seçimden çıkartıldı ise sil
        else :
            iter=self.liststorechoosen.get_iter_first()
            while iter is not None :
                if(self.liststorechoosen[iter][0]==self.liststoremodules[treepath][0]):
                    self.liststorechoosen.remove(iter)
                    self.treeviewchoosen.set_model(self.liststorechoosen)
                    break
                else :
                    iter=self.liststorechoosen.iter_next(iter)

    ## Seçilen dizinin isminin tutulması ve seçme işleminin bitimi
    def on_select_file(self,widget):
        if widget.get_filename() is not None: ## Eğer bir dizin seçildiyse kaydet ve sayfayı kapat
            self.destinationfile=widget.get_filename()
            self.set_page_complete(self.box2,True)
        else :
            pass

    def push_progress_page(self):
        iter = self.liststorechoosen.get_iter_first()
        while iter is not None:
            self.liststoreprogress.append([self.liststorechoosen[iter][0],0])
            iter=self.liststorechoosen.iter_next(iter)

        self.treeviewprogress.set_model(self.liststoreprogress)
        self.on_extract_progress()


    def on_pulse_progressbar(self):

        for item in self.liststoreprogress :
            bar=TarFile("Zips/"+item[0],"ExtractFiles/")
            item[1]+=float(os.path.getsize("ExtractFiles/"+item[0]+"/"))/float(bar.tarsize)*100
        return True

    def on_extract_progress(self):
        for item in self.liststoreprogress :
            bar=TarFile("Zips/"+item[0],"ExtractFiles/")
            bar.extract()

window = Installation()
window.show_all()
Gtk.main()